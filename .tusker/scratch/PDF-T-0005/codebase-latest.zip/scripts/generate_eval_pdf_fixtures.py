#!/usr/bin/env python3
"""Generate tiny deterministic PDF fixtures for parser regression tests."""

from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "eval" / "fixtures" / "pdfs"


def pdf_string(value: str) -> str:
    return value.replace("\\", "\\\\").replace("(", "\\(").replace(")", "\\)")


def write_pdf(path: Path, operations: str) -> None:
    stream = operations.encode("ascii")
    objects = [
        b"<< /Type /Catalog /Pages 2 0 R >>",
        b"<< /Type /Pages /Kids [3 0 R] /Count 1 >>",
        (
            b"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] "
            b"/Resources << /Font << /F1 4 0 R >> >> /Contents 5 0 R >>"
        ),
        b"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>",
        b"<< /Length %d >>\nstream\n%s\nendstream" % (len(stream), stream),
    ]

    chunks = [b"%PDF-1.4\n%\xe2\xe3\xcf\xd3\n"]
    offsets = []
    for idx, obj in enumerate(objects, start=1):
        offsets.append(sum(len(chunk) for chunk in chunks))
        chunks.append(f"{idx} 0 obj\n".encode("ascii"))
        chunks.append(obj)
        chunks.append(b"\nendobj\n")

    xref_offset = sum(len(chunk) for chunk in chunks)
    chunks.append(f"xref\n0 {len(objects) + 1}\n".encode("ascii"))
    chunks.append(b"0000000000 65535 f \n")
    for offset in offsets:
        chunks.append(f"{offset:010d} 00000 n \n".encode("ascii"))
    chunks.append(
        (
            f"trailer\n<< /Size {len(objects) + 1} /Root 1 0 R >>\n"
            f"startxref\n{xref_offset}\n%%EOF\n"
        ).encode("ascii")
    )

    path.write_bytes(b"".join(chunks))


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)

    write_pdf(
        OUT / "ctm_scaled_text.pdf",
        "q\n2 0 0 2 72 120 cm\nBT\n/F1 12 Tf\n0 0 Td\n(Scaled CTM Text) Tj\nET\nQ\n",
    )

    write_pdf(
        OUT / "invisible_ocr_only.pdf",
        "BT\n/F1 12 Tf\n3 Tr\n72 720 Td\n(Invisible OCR Layer Text) Tj\nET\n",
    )

    long_text = " ".join(
        [
            "Split provenance paragraph sentence %03d with stable source text." % idx
            for idx in range(1, 80)
        ]
    )
    write_pdf(
        OUT / "long_split_locations.pdf",
        "BT\n/F1 10 Tf\n72 720 Td\n(%s) Tj\nET\n" % pdf_string(long_text),
    )

    write_pdf(
        OUT / "malformed_text_ops.pdf",
        "\n".join(
            [
                "q",
                "1 0 cm",
                "BT",
                "72 720 Td",
                "(Text before font should be skipped) Tj",
                "123 Tj",
                "1 0 0 1 72 Tm",
                "1 2 TD",
                "ET",
                "Q",
                "",
            ]
        ),
    )


if __name__ == "__main__":
    main()
