use super::{ExtractOptions, ExtractedDocument, PdfInput, PdfTextBackend};
use std::error::Error;
use std::fmt;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct PdfiumUnavailableError;

impl fmt::Display for PdfiumUnavailableError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(
            f,
            "backend-pdfium is compiled as an explicit feature seam, but no PDFium runtime backend is linked yet"
        )
    }
}

impl Error for PdfiumUnavailableError {}

#[derive(Debug, Clone, Copy, Default)]
pub struct PdfiumBackend;

impl PdfiumBackend {
    pub fn new() -> Result<Self, PdfiumUnavailableError> {
        Err(PdfiumUnavailableError)
    }

    pub fn unavailable_reason() -> &'static str {
        "PDFium extraction is not implemented in this build; use the lopdf backend or add a PDFium FFI implementation behind backend-pdfium"
    }
}

impl PdfTextBackend for PdfiumBackend {
    fn extract(
        &self,
        _input: PdfInput<'_>,
        _options: ExtractOptions,
    ) -> Result<ExtractedDocument, Box<dyn Error>> {
        Err(Box::new(PdfiumUnavailableError))
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn pdfium_backend_reports_explicit_unavailable_error() {
        let err = PdfiumBackend::new().expect_err("pdfium backend should be unavailable");
        assert!(err.to_string().contains("no PDFium runtime backend"));

        let backend = PdfiumBackend;
        let err = backend
            .extract(PdfInput { bytes: b"%PDF" }, ExtractOptions::default())
            .expect_err("extract should report unavailable");
        assert!(err.to_string().contains("no PDFium runtime backend"));
    }
}
