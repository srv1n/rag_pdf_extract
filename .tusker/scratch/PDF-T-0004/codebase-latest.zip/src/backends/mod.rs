use crate::{BoundingBox, FontWeight, TextSegment};
use serde::{Deserialize, Serialize};

#[cfg(feature = "backend-pdfium")]
pub mod pdfium;

#[cfg(feature = "backend-pdfium")]
pub use pdfium::{PdfiumBackend, PdfiumUnavailableError};

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum ExtractionBackend {
    Lopdf,
    Pdfium,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum SourceKind {
    Page,
    FormXObject,
    Annotation,
    Pattern,
}

#[derive(Debug, Clone)]
pub struct CharSpan {
    pub output_start: usize,
    pub output_end: usize,
    pub page: u32,
    pub char_start: usize,
    pub char_end: usize,
    pub bbox: BoundingBox,
}

#[derive(Debug, Clone)]
pub struct TextRun {
    pub text: String,
    pub page: u32,
    pub bbox: BoundingBox,
    pub char_spans: Vec<CharSpan>,
    pub font_name: Option<String>,
    pub font_size: Option<f64>,
    pub font_weight: Option<FontWeight>,
    pub rotation_deg: f64,
    pub source_kind: SourceKind,
}

#[derive(Debug, Clone)]
pub struct ExtractedPage {
    pub page_num: u32,
    pub width: f64,
    pub height: f64,
    pub rotation: i32,
    pub text_runs: Vec<TextRun>,
}

#[derive(Debug, Clone)]
pub struct ExtractedDocument {
    pub pages: Vec<ExtractedPage>,
    pub backend: ExtractionBackend,
}

#[derive(Debug, Clone, Default)]
pub struct ExtractOptions {
    pub max_tokens: Option<usize>,
    pub all_texts: bool,
    pub detect_vertical: bool,
}

pub struct PdfInput<'a> {
    pub bytes: &'a [u8],
}

pub trait PdfTextBackend {
    fn extract(
        &self,
        input: PdfInput<'_>,
        options: ExtractOptions,
    ) -> Result<ExtractedDocument, Box<dyn std::error::Error>>;
}

pub(crate) fn text_run_to_segment(run: &TextRun) -> TextSegment {
    TextSegment {
        content: run.text.clone(),
        font_size: run.font_size.unwrap_or(12.0),
        transformed_font_size: run.font_size.unwrap_or(12.0),
        x: run.bbox.x,
        y: run.bbox.y,
        is_bold: run
            .font_weight
            .as_ref()
            .map(|weight| weight.is_bold())
            .unwrap_or(false),
        font_name: run.font_name.clone().unwrap_or_default(),
        font_weight: run.font_weight.clone().unwrap_or(FontWeight::Regular),
        is_italic: false,
        page_num: run.page,
        cutat: "backend".to_string(),
        fill_color: None,
        stroke_color: None,
        char_start: run.char_spans.first().map(|s| s.char_start).unwrap_or(0),
        char_end: run
            .char_spans
            .last()
            .map(|s| s.char_end)
            .unwrap_or_else(|| run.text.chars().count()),
        width: run.bbox.width,
        height: run.bbox.height,
        word_count: crate::chunk_accumulator::count_words(&run.text),
    }
}
