# PDF Parser Review Handoff

Date: 2026-05-28

## Scope

Implemented the review pack under `artifacts/pdf_parser_review_tasks` as production code plus gates. The implementation keeps the existing `ContentCore` / `ContentExt` schema path and current lopdf backend as default, while adding the policy/type seams needed for a future PDFium raw backend.

## Implemented

| Task | Status | Evidence |
| --- | --- | --- |
| 01 eval harness | Done | `examples/stage_benchmark.rs`, `eval/fixtures/pdf_manifest.json`, `eval/runs/stage_benchmark_current/` |
| 02 header/footer | Done | `src/document/header_footer.rs`; unit tests cover one-page, two-page, repeated header, variance |
| 03 visibility policy | Done | `src/document/visibility.rs`; layout and no-layout use the same policy path |
| 04 Form XObject CTM | Done | `StreamContext` + explicit child initial CTM in `src/lib.rs`; recursion depth guard |
| 05 vertical dedup | Done | vertical grouping gated by page-level signal and overlap suppression in `src/lib.rs` |
| 06 location fidelity | Done for current backend | heading locations use heading source segments; table markdown keeps source ranges; chunk split locations are subset; grouped fragments default; `content_hash` split from source-stable `chunk_id` |
| 07 PDFium backend spike | Interface done | `src/backends/mod.rs`; feature flags in `Cargo.toml`; actual FFI backend remains behind `backend-pdfium` seam |
| 08 heading/context | Done for known bug | pending headings preserve their own source locations; context remains distinguishable through location metadata notes |
| 09 tables/columns/order | Done for current backend | table cells retain source char ranges; same-y sort includes x; benchmark emits table/location-sensitive metrics |
| 10 packaging/license | Done as package contract | feature flags added: `backend-lopdf`, `backend-pdfium`, `ocr-tesseract`; packaging guidance remains in review docs |
| 11 acceptance gates | Done | `cargo test`; `stage_benchmark`; founder regression |

## Validation

```text
cargo fmt
cargo test
  PASS: 44 passed, 5 suites

cargo run --example stage_benchmark -- --manifest eval/fixtures/pdf_manifest.json --out-dir eval/runs/stage_benchmark_current
  PASS: documents_stack, layout_4_pdf, founder_legal_pack_smoke

cargo run --example founder_regression
  PASS: passed=3, warnings=0, hard_failures=0
```

## Review Notes

- The current backend still has segment-level, not PDFium char-level, source spans. The new `span_map` and `backends` modules define the shape needed to upgrade this without changing downstream chunking.
- `backend-pdfium` is intentionally a feature seam, not a mandatory dependency. Shipping PDFium should wait for the native backend implementation and per-platform packaging review.
- `all_texts` remains fixture/workload-specific. Founder legal regression uses it because that corpus needs Form XObject text; general examples and the stage harness default to safer settings unless a fixture opts in.
