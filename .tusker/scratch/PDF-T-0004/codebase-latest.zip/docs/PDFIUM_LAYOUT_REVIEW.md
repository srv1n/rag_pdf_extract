# PDFium / LiteParse Layout Review

Date: 2026-05-28
Repo baseline: `rag_pdf_extract` `de635f7` with existing local changes
LiteParse baseline: `run-llama/liteparse` `ae1ae83`, `lit 2.0.2`, built with `--no-default-features`

## Take

Do not replace the current pipeline wholesale with LiteParse.

The high-ROI path is narrower:

1. Keep our existing chunking, CDC/location schema, hard token caps, heading stack, and `ContentCore`/`ContentExt` output.
2. Fix the local layout path first. The major extraction errors are in our `LAParams` path, not in the core chunker.
3. Prototype PDFium as an optional raw extraction backend that maps PDFium/LiteParse character items into our `TextSegment` model before post-processing.
4. Treat LiteParse `parse` output as unsuitable for source citations/highlights, because its projection stage rewrites item `x`/`y` into rendered text-grid coordinates.

## Benchmarks

Artifacts:

| Run | Location |
| --- | --- |
| Broad corpus benchmark | `/tmp/rzn-liteparse-bench/runs/summary.json` |
| Stage benchmark | `/tmp/rzn-pdf-stage-bench/run/summary.json` |
| Temporary stage harness | `/tmp/rzn-pdf-stage-bench` |

OCR was disabled on both sides. The broad benchmark compared our release `regression_pack` path against `lit parse --format json --no-ocr --quiet`. The stage benchmark compared:

| Stage | Meaning |
| --- | --- |
| `pdftotext` | Poppler sanity reference |
| `lite_raw` | LiteParse raw PDFium extraction (`lit extract`) |
| `lite_parse` | LiteParse projected parse output (`lit parse`) |
| `ours_no_layout` | `parse_pdf(..., laparams=None)` |
| `ours_layout` | `parse_pdf(..., LAParams { all_texts=true, detect_vertical=true })` |

### Stage Results

Normalized chars remove layout-only whitespace. This is the right number for deciding whether content volume matches.

| Doc | `pdftotext` | `lite_raw` | `lite_parse` | `ours_no_layout` | `ours_layout` | Read |
| --- | ---: | ---: | ---: | ---: | ---: | --- |
| hello, 1 page | 21 | 21 | 21 | 0 | 0 | Header/footer filter removed everything |
| `4.pdf`, 18 pages | 49,294 | 49,610 | 49,302 | 49,144 | 95,037 | Layout almost 2x |
| `10.pdf`, 47 pages | 165,353 | 166,799 | 165,202 | 162,651 | 333,996 | Layout almost 2x |
| `documents_stack.pdf`, 1 page | 1,600 | 1,613 | 1,598 | 0 | 0 | Header/footer filter removed everything |

Single-page retest with `PDF_EXTRACT_SKIP_HEADER_FOOTER=1`:

| Doc | `ours_no_layout` | `ours_layout` | Read |
| --- | ---: | ---: | --- |
| hello | 21 chars, correct | 41 chars, corrupted | Layout breaks even trivial text |
| `documents_stack.pdf` | 1,493 chars | 3,080 chars, corrupted/inflated | Header/footer is not the only issue |

Broad corpus comparison still matters for speed and scale:

| Doc | Ours seconds | Ours chars | LiteParse seconds | LiteParse chars | Read |
| --- | ---: | ---: | ---: | ---: | --- |
| CCI legal/Form XObject | 0.698 | 199,399 | 0.378 | 109,654 | Ours likely inflated |
| Scientific `6.pdf` | 0.733 | 69,914 | 0.105 | 45,180 | Ours likely inflated |
| `10.pdf` | 1.195 | 333,506 | 0.111 | 194,310 | Layout inflated |
| `documents_stack.pdf` | 0.192 | 0 | 0.016 | 2,236 | Header/footer false positive |
| `ocr.pdf` no OCR | 0.182 | 0 | 0.034 | 7,221 | PDFium sees embedded/invisible text |
| Energy Watchdog | 0.727 | 227,455 | 0.082 | 122,583 | Ours likely inflated |
| Puttaswamy | 3.214 | 1,488,153 | 0.549 | 974,452 | Ours likely inflated/glyph garbage |

## What Is Wrong

### 1. Header/footer filtering deletes single-page PDFs

Code:

| File | Finding |
| --- | --- |
| `src/document/header_footer.rs:123` | `analyze()` uses `occurrence_count / page_count`. |
| `src/document/header_footer.rs:152` | `occurrence_ratio >= 0.8` marks text as header/footer even without a pattern match. |
| `src/document/processing.rs:940` | Every segment is fed into the detector before filtering. |
| `src/document/processing.rs:961` | Matching normalized text is removed from the document. |

On a one-page PDF, every unique segment has ratio `1.0`. That means normal content is classified as repeated boilerplate. This explains `hello` and `documents_stack.pdf` returning zero chunks.

Fix policy:

- Disable repetition-based header/footer detection for `page_count < 3`.
- For 2-page documents, only remove strict page-number/header/footer regex matches.
- Count distinct pages, not raw occurrences, before computing the ratio.
- Require consistent top/bottom bands before removal. The current hard-coded `792.0` page height in `processing.rs` is too loose for arbitrary media boxes.

### 2. Layout mode uses weaker visibility filtering than no-layout

Code:

| File | Finding |
| --- | --- |
| `src/lib.rs:3607` | Layout mode admits render modes `0 | 1 | 2` directly. |
| `src/lib.rs:3611` | No-layout mode uses `self.is_visible_text(...)`, including transform/color/media-box checks. |

This creates a split-brain extractor: the path we use for layout/headings has less visibility filtering than the simpler path. That is backwards. Layout must use the same visibility predicate, then add only layout grouping.

LiteParse/PDFium has a better policy here:

- It pre-scans the page to decide whether invisible text is probably redundant OCR text or the only useful text layer.
- It skips generated non-space characters.
- It drops sentinel Unicode values.
- It uses strict and loose character boxes separately.

Relevant LiteParse code: `/tmp/rzn-liteparse-bench/liteparse/crates/liteparse/src/extract.rs:97`, `:192`, `:238`, `:248`, `:354`.

Relevant PDFium APIs expose this information directly: `FPDFText_IsGenerated`, `FPDFText_GetTextObject`, `FPDFText_GetTextRenderMode`, `FPDFText_GetCharBox`, `FPDFText_GetLooseCharBox`, `FPDFText_GetMatrix`.

### 3. `all_texts=true` Form XObject recursion can duplicate or misplace text

Code:

| File | Finding |
| --- | --- |
| `src/lib.rs:4131` | Form XObject text is enabled by `LAParams.all_texts`. |
| `src/lib.rs:4164` | Parent graphics state CTM is mutated before recursion. |
| `src/lib.rs:4172` | Recursive `process_stream()` call starts a new local graphics state. |
| `src/lib.rs:3146` | Each `process_stream()` builds a fresh initial CTM. |

The suspicious part: setting `gs.ctm` in the caller does not obviously propagate into the callee because `process_stream()` initializes its own stream-local state. So Form XObject text may be extracted, but with an incorrect parent transform. Separately, forms often contain repeated content, decorative text, annotations, or alternate text layers. We currently accept all of it when `all_texts=true`.

Fix policy:

- Add an explicit `parent_ctm` or `initial_ctm` parameter to recursive stream processing.
- Preserve Form XObject resource lookup, but make the transform path auditable.
- Deduplicate text by normalized content plus bbox overlap before glyph grouping.
- Gate Form XObject text: enable by default only when page-native text is sparse, or when the form contributes non-overlapping visible text.

### 4. Vertical detection appends duplicate lines

Code:

| File | Finding |
| --- | --- |
| `src/lib.rs:4497` | `detect_vertical` derives vertical glyphs from the same glyph set. |
| `src/lib.rs:4501` | The filter `height > 1.5 * width` can match normal glyphs. |
| `src/lib.rs:4584` | Vertical lines are appended to the same `lines` vector. |
| `src/lib.rs:4704` | Emitted `LA-Line` segments do not know whether they are duplicate horizontal or true vertical text. |

For Latin documents, many normal characters are taller than they are wide. Appending vertical interpretations without marking/removing consumed glyphs is a duplication machine.

Fix policy:

- Default `detect_vertical=false` for Latin/legal fixtures unless actual vertical writing is detected.
- Require character angle/writing-mode evidence, not only bbox aspect ratio.
- If vertical extraction emits a line, mark the source glyphs consumed or ensure it does not overlap a horizontal line with the same normalized text.

### 5. LiteParse parse output is not citation-safe

Code:

| File | Finding |
| --- | --- |
| `/tmp/rzn-liteparse-bench/liteparse/crates/liteparse/src/projection.rs:2551` | `item.item.x` is overwritten with projected text column. |
| `/tmp/rzn-liteparse-bench/liteparse/crates/liteparse/src/projection.rs:2552` | `item.item.y` is overwritten with projected line index. |

This is fine for rendering a readable text grid. It is wrong for our product's PDF citation/highlight needs. If we use LiteParse, use the raw extraction layer or fork a mode that preserves both raw and projected coordinates.

## Reference Implementation Notes

### PDFium

PDFium's public text API exposes a character stream per page. Its header documents that `FPDFText_CountChars` includes generated spaces/newlines and that each character has an index. The implementation builds a `CPDF_TextPage`, then returns per-character font, render mode, color, matrix, origin, strict char box, loose char box, and text object metadata through C APIs.

Useful design point: PDFium already owns the hard PDF parts: CMaps, embedded fonts, text object traversal, render modes, page transforms, and text object metadata. We should not rebuild that in Rust if the local installer can vendor a PDFium shared library cleanly.

### LiteParse

LiteParse is a thin, pragmatic PDFium consumer:

- Apache-2.0.
- Default feature enables Tesseract; for Tauri packaging, build with `default-features=false` unless we intentionally ship OCR.
- Runtime loading order supports `PDFIUM_LIB_PATH`, a baked build path, native-extension directory, executable directory, then system library search.
- Raw extraction is character-based and location-aware.
- `parse` projection improves readable text, but mutates coordinates.

Relevant local refs:

| File | Why it matters |
| --- | --- |
| `/tmp/rzn-liteparse-bench/liteparse/crates/liteparse/src/extract.rs` | Raw char extraction and dedup policy |
| `/tmp/rzn-liteparse-bench/liteparse/crates/liteparse/src/projection.rs` | Readable projection, unsafe for raw coordinates |
| `/tmp/rzn-liteparse-bench/liteparse/crates/pdfium-sys/src/dynamic.rs` | Runtime `libpdfium` loading |
| `/tmp/rzn-liteparse-bench/liteparse/crates/liteparse/Cargo.toml` | Tesseract default feature |

### Poppler `pdftotext`

Poppler is useful as an independent oracle for normalized text volume. In the small-doc benchmark, `pdftotext`, `lite_raw`, `lite_parse`, and `ours_no_layout` all cluster tightly. That is enough to say the 2x layout output is our bug, not a PDF ambiguity.

## Integration Shape

Target architecture:

```text
PDF bytes
  |
  +-- backend: lopdf/no-layout or PDFium raw
        |
        v
  Vec<TextSegment> with page, bbox, char range, font-ish metadata
        |
        v
  existing processing.rs
    - merge continuations
    - header/footer filtering
    - tables
    - headings
    - ChunkAccumulator
        |
        v
  ContentCore + ContentExt + PdfLocation fragments
```

Non-goals:

- Do not feed LiteParse projected JSON directly into `ContentExt`.
- Do not trade away CDC/hard token cap behavior for a faster extractor.
- Do not require system PDFium/Tesseract installation for the desktop app.

Packaging constraints for Tauri:

| Concern | Decision |
| --- | --- |
| Extra system deps | Vendor `libpdfium` inside the app bundle. |
| Runtime lookup | Set/derive `PDFIUM_LIB_PATH`, or load from app resource/exe directory. |
| OCR | Keep disabled by default; Tesseract is a separate product decision. |
| License | Track Apache-2.0 LiteParse and PDFium/third-party notices. |
| Cross-platform | Validate macOS `dylib`, Windows `dll`, Linux `so` packaging separately. |

## Work Plan

Order matters. Fix local correctness before adding a second backend.

| Step | Task | Why |
| ---: | --- | --- |
| 1 | Add a durable stage benchmark harness | Prevent more apples-to-oranges char-count debates |
| 2 | Fix header/footer single-page false positives | Current pipeline can output zero for valid PDFs |
| 3 | Align layout visibility with no-layout | Stop admitting hidden/decorative text in layout mode |
| 4 | Add layout duplication diagnostics | We need per-stage counts before touching Form XObjects |
| 5 | Fix Form XObject transform propagation and dedup | `all_texts=true` is useful but currently unsafe |
| 6 | Guard vertical detection | `detect_vertical=true` should not duplicate Latin text |
| 7 | Add parity gates | Lock `ours_layout` within expected volume of references |
| 8 | Prototype PDFium raw backend | Borrow PDFium maturity while preserving our schema |
| 9 | Package PDFium for Tauri | Make it work as a single desktop installer |
| 10 | Update integration docs/defaults | Stop accidental use of unsafe layout settings |

## Acceptance Gates

Minimum gates before calling layout fixed:

| Fixture | Gate |
| --- | --- |
| hello | no-layout and layout both extract `Hello PDF Second line`; nonzero chunks |
| `documents_stack.pdf` | no header/footer deletion; normalized chars within 15% of `pdftotext` or PDFium raw |
| `4.pdf` | layout normalized chars within 10% of no-layout and PDFium raw |
| `10.pdf` | layout normalized chars within 10% of no-layout and PDFium raw |
| Founder legal pack | no token cap regressions; zero over-cap chunks |
| Citation metadata | every emitted chunk keeps valid page fragments and bbox unions |

PDFium backend prototype gates:

| Gate | Requirement |
| --- | --- |
| Location | Raw PDFium bbox maps to `PdfLocation` fragments without projection mutation |
| Chunking | Existing `ChunkAccumulator` remains the only chunking authority |
| Packaging | App bundle runs without system PDFium/Tesseract |
| Performance | Faster than current layout path on long docs, without lower text parity |
| Fallback | lopdf path remains available behind a feature/setting |

## Logged Tasks

These are also recorded in `.beads/issues.jsonl` under epic `rag_pdf_extract-pdfium-layout`.

| ID | Title | Priority |
| --- | --- | ---: |
| `rag_pdf_extract-pdfium-layout` | PDFium/LiteParse parity and layout correctness | 1 |
| `rag_pdf_extract-pdfium-layout.1` | Add stage-level PDF extraction benchmark harness | 1 |
| `rag_pdf_extract-pdfium-layout.2` | Fix single-page header/footer false positives | 1 |
| `rag_pdf_extract-pdfium-layout.3` | Align layout visibility filtering with no-layout | 1 |
| `rag_pdf_extract-pdfium-layout.4` | Instrument layout duplication by stage | 1 |
| `rag_pdf_extract-pdfium-layout.5` | Deduplicate and correctly transform Form XObject text | 1 |
| `rag_pdf_extract-pdfium-layout.6` | Make vertical text detection non-duplicating | 2 |
| `rag_pdf_extract-pdfium-layout.7` | Add small-document layout parity gates | 1 |
| `rag_pdf_extract-pdfium-layout.8` | Prototype optional PDFium raw extraction backend | 2 |
| `rag_pdf_extract-pdfium-layout.9` | Package PDFium backend for Tauri desktop | 2 |
| `rag_pdf_extract-pdfium-layout.10` | Document safe layout defaults and integration guidance | 3 |

## Sources

- PDFium public text API: https://pdfium.googlesource.com/pdfium/+/main/public/fpdf_text.h
- PDFium `fpdf_text.cpp` implementation: https://pdfium.googlesource.com/pdfium.git/+/refs/heads/chromium/6593/fpdfsdk/fpdf_text.cpp
- LiteParse repository: https://github.com/run-llama/liteparse
