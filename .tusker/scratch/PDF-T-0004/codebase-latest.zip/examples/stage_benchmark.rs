use pdf_extract::{
    decompress_content_ext, extract_pdf_location, parse_pdf, ExtractionResult, LAParams,
};
use serde::{Deserialize, Serialize};
use std::env;
use std::error::Error;
use std::fs;
use std::path::{Path, PathBuf};
use std::time::{Instant, SystemTime, UNIX_EPOCH};

#[derive(Debug, Deserialize, Serialize)]
struct FixtureManifest {
    fixtures: Vec<Fixture>,
}

#[derive(Debug, Deserialize, Serialize)]
struct Fixture {
    id: String,
    path: String,
    category: String,
    #[serde(default)]
    expected: Expected,
}

#[derive(Debug, Default, Deserialize, Serialize)]
struct Expected {
    min_chunks: Option<usize>,
    must_contain: Option<Vec<String>>,
    max_over_cap_chunks: Option<usize>,
    location_required: Option<bool>,
    max_identical_location_sibling_count: Option<usize>,
    min_source_span_coverage_ratio: Option<f64>,
    min_output_span_coverage_ratio: Option<f64>,
    layout_to_no_layout_normalized_char_ratio_min: Option<f64>,
    layout_to_no_layout_normalized_char_ratio_max: Option<f64>,
}

#[derive(Debug, Serialize)]
struct BenchmarkReport {
    generated_at_epoch_ms: u128,
    manifest_path: String,
    fixtures: Vec<FixtureReport>,
}

#[derive(Debug, Serialize)]
struct FixtureReport {
    fixture_id: String,
    path: String,
    category: String,
    status: String,
    stages: StageSet,
    references: ReferenceSet,
    chunks: ChunkMetrics,
    location: LocationMetrics,
    failures: Vec<String>,
}

#[derive(Debug, Default, Serialize)]
struct StageSet {
    ours_no_layout_post_filters: Option<StageMetrics>,
    ours_layout_post_filters: Option<StageMetrics>,
    ours_chunks: Option<StageMetrics>,
}

#[derive(Debug, Default, Serialize)]
struct ReferenceSet {
    poppler_pdftotext: ReferenceMetrics,
    pdfium_raw: ReferenceMetrics,
}

#[derive(Debug, Default, Serialize)]
struct ReferenceMetrics {
    status: String,
    normalized_chars: Option<usize>,
    delta_to_layout_chars: Option<i64>,
    note: Option<String>,
}

#[derive(Debug, Clone, Serialize)]
struct StageMetrics {
    normalized_chars: usize,
    raw_chars: usize,
    chunk_count: usize,
    duplicate_line_ratio: f64,
    duration_ms: u128,
}

#[derive(Debug, Default, Serialize)]
struct ChunkMetrics {
    chunk_count: usize,
    max_tokens: usize,
    max_chunk_tokens: usize,
    over_cap_chunks: usize,
    empty_chunks: usize,
    chunks_without_location: usize,
}

#[derive(Debug, Default, Serialize)]
struct LocationMetrics {
    fragment_count: usize,
    invalid_bbox_count: usize,
    zero_area_bbox_count: usize,
    fragments_outside_page_count: usize,
    identical_location_sibling_count: usize,
    source_span_coverage_ratio: f64,
    output_span_coverage_ratio: f64,
    synthetic_char_ratio: f64,
    fragment_density: f64,
    highlight_replay_failures: usize,
}

fn main() -> Result<(), Box<dyn Error>> {
    let args: Vec<String> = env::args().collect();
    let manifest_path = read_flag(&args, "--manifest")
        .map(PathBuf::from)
        .unwrap_or_else(|| PathBuf::from("eval/fixtures/pdf_manifest.json"));
    let out_dir = read_flag(&args, "--out-dir")
        .map(PathBuf::from)
        .unwrap_or_else(|| PathBuf::from("eval/runs/stage_benchmark_current"));
    let max_tokens = read_flag(&args, "--max-tokens")
        .and_then(|v| v.parse().ok())
        .unwrap_or(500usize);

    fs::create_dir_all(&out_dir)?;
    let raw = fs::read_to_string(&manifest_path)?;
    let manifest: FixtureManifest = serde_json::from_str(&raw)?;
    let manifest_dir = manifest_path.parent().unwrap_or_else(|| Path::new("."));

    let mut fixture_reports = Vec::new();
    for fixture in manifest.fixtures {
        let path = resolve_path(manifest_dir, &fixture.path);
        fixture_reports.push(run_fixture(&fixture, &path, max_tokens));
    }

    let report = BenchmarkReport {
        generated_at_epoch_ms: SystemTime::now().duration_since(UNIX_EPOCH)?.as_millis(),
        manifest_path: manifest_path.display().to_string(),
        fixtures: fixture_reports,
    };

    fs::write(
        out_dir.join("stage_benchmark.json"),
        serde_json::to_vec_pretty(&report)?,
    )?;
    fs::write(out_dir.join("stage_benchmark.md"), render_markdown(&report))?;

    let failed = report.fixtures.iter().any(|f| f.status == "failed");
    println!(
        "Report JSON: {}",
        out_dir.join("stage_benchmark.json").display()
    );
    println!(
        "Report MD: {}",
        out_dir.join("stage_benchmark.md").display()
    );
    if failed {
        std::process::exit(1);
    }
    Ok(())
}

fn run_fixture(fixture: &Fixture, path: &Path, max_tokens: usize) -> FixtureReport {
    if !path.exists() {
        return FixtureReport {
            fixture_id: fixture.id.clone(),
            path: path.display().to_string(),
            category: fixture.category.clone(),
            status: "failed".to_string(),
            stages: StageSet::default(),
            references: ReferenceSet::default(),
            chunks: ChunkMetrics::default(),
            location: LocationMetrics::default(),
            failures: vec!["fixture missing".to_string()],
        };
    }

    let no_layout = timed_parse(path, max_tokens, None);
    let mut lp = LAParams::default();
    lp.all_texts = fixture.category == "form_xobject";
    lp.detect_vertical = fixture.category == "vertical";
    let layout = timed_parse(path, max_tokens, Some(lp));

    let mut failures = Vec::new();
    let mut stages = StageSet::default();
    let mut references = ReferenceSet::default();
    let mut chunks = ChunkMetrics {
        max_tokens,
        ..ChunkMetrics::default()
    };
    let mut location = LocationMetrics::default();

    if let Ok((docs, duration_ms)) = &no_layout {
        stages.ours_no_layout_post_filters = Some(stage_metrics(docs, *duration_ms));
    }

    match layout {
        Ok((docs, duration_ms)) => {
            let layout_stage = stage_metrics(&docs, duration_ms);
            chunks = chunk_metrics(&docs, max_tokens);
            location = location_metrics(&docs);
            stages.ours_chunks = Some(layout_stage.clone());
            stages.ours_layout_post_filters = Some(layout_stage);
            references = reference_metrics(path, &stages);
            apply_expectations(fixture, &docs, &chunks, &location, &stages, &mut failures);
        }
        Err(err) => failures.push(format!("layout parse failed: {err}")),
    }

    FixtureReport {
        fixture_id: fixture.id.clone(),
        path: path.display().to_string(),
        category: fixture.category.clone(),
        status: if failures.is_empty() {
            "passed"
        } else {
            "failed"
        }
        .to_string(),
        stages,
        references,
        chunks,
        location,
        failures,
    }
}

fn timed_parse(
    path: &Path,
    max_tokens: usize,
    laparams: Option<LAParams>,
) -> Result<(Vec<ExtractionResult>, u128), Box<dyn Error>> {
    let started = Instant::now();
    let docs = parse_pdf(
        path.to_str().unwrap_or_default(),
        1,
        "file",
        None,
        None,
        None,
        Some(max_tokens),
        laparams,
        Some(true),
    )?;
    Ok((docs, started.elapsed().as_millis()))
}

fn stage_metrics(docs: &[ExtractionResult], duration_ms: u128) -> StageMetrics {
    let text = docs
        .iter()
        .map(|doc| doc.content_core.content.as_str())
        .collect::<Vec<_>>()
        .join("\n");
    StageMetrics {
        normalized_chars: normalized_chars(&text),
        raw_chars: text.chars().count(),
        chunk_count: docs.len(),
        duplicate_line_ratio: duplicate_line_ratio(&text),
        duration_ms,
    }
}

fn chunk_metrics(docs: &[ExtractionResult], max_tokens: usize) -> ChunkMetrics {
    let tokenizer = tiktoken_rs::get_bpe_from_model("gpt-4o").ok();
    let mut out = ChunkMetrics {
        chunk_count: docs.len(),
        max_tokens,
        ..ChunkMetrics::default()
    };
    for doc in docs {
        if doc.content_core.content.trim().is_empty() {
            out.empty_chunks += 1;
        }
        let tokens = tokenizer
            .as_ref()
            .map(|tok| tok.encode_ordinary(&doc.content_core.content).len())
            .unwrap_or(doc.content_core.token_count as usize);
        out.max_chunk_tokens = out.max_chunk_tokens.max(tokens);
        if tokens > max_tokens {
            out.over_cap_chunks += 1;
        }
        if extract_pdf_location(&doc.content_ext)
            .map(|loc| loc.fragments.is_empty())
            .unwrap_or(true)
        {
            out.chunks_without_location += 1;
        }
    }
    out
}

fn location_metrics(docs: &[ExtractionResult]) -> LocationMetrics {
    let mut out = LocationMetrics::default();
    let mut chunks_with_fragments = 0usize;
    let mut chunks_with_output_spans = 0usize;
    let mut synthetic_chars = 0usize;
    let mut spanned_chars = 0usize;
    let mut seen_locations = std::collections::HashSet::new();
    for doc in docs {
        if let Ok(loc) = extract_pdf_location(&doc.content_ext) {
            if !loc.fragments.is_empty() {
                chunks_with_fragments += 1;
            }
            let key = serde_json::to_string(&loc.fragments).unwrap_or_default();
            if !seen_locations.insert(key) {
                out.identical_location_sibling_count += 1;
            }
            for frag in loc.fragments {
                out.fragment_count += 1;
                if !frag.bbox.x.is_finite()
                    || !frag.bbox.y.is_finite()
                    || !frag.bbox.width.is_finite()
                    || !frag.bbox.height.is_finite()
                    || frag.bbox.width < 0.0
                    || frag.bbox.height < 0.0
                {
                    out.invalid_bbox_count += 1;
                }
                if frag.bbox.width == 0.0 || frag.bbox.height == 0.0 {
                    out.zero_area_bbox_count += 1;
                }
                if frag.bbox.x < -1000.0 || frag.bbox.y < -1000.0 {
                    out.fragments_outside_page_count += 1;
                }
            }
        }
        if let Ok(ext) = decompress_content_ext(&doc.content_ext) {
            if let Some(spans) = ext.get("output_spans").and_then(|value| value.as_array()) {
                if !spans.is_empty() {
                    chunks_with_output_spans += 1;
                }
                for span in spans {
                    let start = span
                        .get("output_start")
                        .and_then(|value| value.as_u64())
                        .unwrap_or(0) as usize;
                    let end = span
                        .get("output_end")
                        .and_then(|value| value.as_u64())
                        .unwrap_or(start as u64) as usize;
                    let len = end.saturating_sub(start);
                    spanned_chars += len;
                    if span
                        .get("source")
                        .and_then(|source| source.get("Synthetic"))
                        .is_some()
                    {
                        synthetic_chars += len;
                    }
                }
            }
        }
    }
    out.fragment_density = if docs.is_empty() {
        0.0
    } else {
        out.fragment_count as f64 / docs.len() as f64
    };
    out.source_span_coverage_ratio = if docs.is_empty() {
        0.0
    } else {
        chunks_with_fragments as f64 / docs.len() as f64
    };
    out.output_span_coverage_ratio = if docs.is_empty() {
        0.0
    } else {
        chunks_with_output_spans as f64 / docs.len() as f64
    };
    out.synthetic_char_ratio = if spanned_chars == 0 {
        0.0
    } else {
        synthetic_chars as f64 / spanned_chars as f64
    };
    out
}

fn reference_metrics(path: &Path, stages: &StageSet) -> ReferenceSet {
    let layout_chars = stages
        .ours_layout_post_filters
        .as_ref()
        .map(|stage| stage.normalized_chars)
        .unwrap_or(0);
    ReferenceSet {
        poppler_pdftotext: poppler_reference(path, layout_chars),
        pdfium_raw: ReferenceMetrics {
            status: "missing_reference".to_string(),
            normalized_chars: None,
            delta_to_layout_chars: None,
            note: Some("PDFium raw reference is unavailable in this build".to_string()),
        },
    }
}

fn poppler_reference(path: &Path, layout_chars: usize) -> ReferenceMetrics {
    let output = std::process::Command::new("pdftotext")
        .arg("-layout")
        .arg(path)
        .arg("-")
        .output();
    match output {
        Ok(output) if output.status.success() => {
            let text = String::from_utf8_lossy(&output.stdout);
            let normalized = normalized_chars(&text);
            ReferenceMetrics {
                status: "available".to_string(),
                normalized_chars: Some(normalized),
                delta_to_layout_chars: Some(layout_chars as i64 - normalized as i64),
                note: None,
            }
        }
        Ok(output) => ReferenceMetrics {
            status: "missing_reference".to_string(),
            normalized_chars: None,
            delta_to_layout_chars: None,
            note: Some(format!("pdftotext exited with {}", output.status)),
        },
        Err(err) => ReferenceMetrics {
            status: "missing_reference".to_string(),
            normalized_chars: None,
            delta_to_layout_chars: None,
            note: Some(format!("pdftotext unavailable: {err}")),
        },
    }
}

fn apply_expectations(
    fixture: &Fixture,
    docs: &[ExtractionResult],
    chunks: &ChunkMetrics,
    location: &LocationMetrics,
    stages: &StageSet,
    failures: &mut Vec<String>,
) {
    if let Some(min_chunks) = fixture.expected.min_chunks {
        if chunks.chunk_count < min_chunks {
            failures.push(format!(
                "chunk_count {} < expected {}",
                chunks.chunk_count, min_chunks
            ));
        }
    }
    if let Some(max_over_cap) = fixture.expected.max_over_cap_chunks {
        if chunks.over_cap_chunks > max_over_cap {
            failures.push(format!(
                "over_cap_chunks {} > expected {}",
                chunks.over_cap_chunks, max_over_cap
            ));
        }
    }
    if fixture.expected.location_required.unwrap_or(false) && chunks.chunks_without_location > 0 {
        failures.push(format!(
            "{} chunks without location",
            chunks.chunks_without_location
        ));
    }
    if let Some(max_identical) = fixture.expected.max_identical_location_sibling_count {
        if location.identical_location_sibling_count > max_identical {
            failures.push(format!(
                "identical_location_sibling_count {} > expected {}",
                location.identical_location_sibling_count, max_identical
            ));
        }
    }
    if let Some(min) = fixture.expected.min_source_span_coverage_ratio {
        if location.source_span_coverage_ratio < min {
            failures.push(format!(
                "source_span_coverage_ratio {:.3} < {:.3}",
                location.source_span_coverage_ratio, min
            ));
        }
    }
    if let Some(min) = fixture.expected.min_output_span_coverage_ratio {
        if location.output_span_coverage_ratio < min {
            failures.push(format!(
                "output_span_coverage_ratio {:.3} < {:.3}",
                location.output_span_coverage_ratio, min
            ));
        }
    }
    for needle in fixture.expected.must_contain.as_deref().unwrap_or(&[]) {
        if !docs
            .iter()
            .any(|doc| doc.content_core.content.contains(needle))
        {
            failures.push(format!("missing required text `{needle}`"));
        }
    }
    if let (Some(layout), Some(no_layout)) = (
        stages.ours_layout_post_filters.as_ref(),
        stages.ours_no_layout_post_filters.as_ref(),
    ) {
        if no_layout.normalized_chars > 0 {
            let ratio = layout.normalized_chars as f64 / no_layout.normalized_chars as f64;
            if let Some(min) = fixture
                .expected
                .layout_to_no_layout_normalized_char_ratio_min
            {
                if ratio < min {
                    failures.push(format!("layout/no-layout char ratio {ratio:.3} < {min:.3}"));
                }
            }
            if let Some(max) = fixture
                .expected
                .layout_to_no_layout_normalized_char_ratio_max
            {
                if ratio > max {
                    failures.push(format!("layout/no-layout char ratio {ratio:.3} > {max:.3}"));
                }
            }
        }
    }
    if location.invalid_bbox_count > 0 || location.zero_area_bbox_count > 0 {
        failures.push("invalid or zero-area bbox fragments found".to_string());
    }
}

fn normalized_chars(text: &str) -> usize {
    text.split_whitespace()
        .collect::<Vec<_>>()
        .join(" ")
        .chars()
        .count()
}

fn duplicate_line_ratio(text: &str) -> f64 {
    let lines: Vec<String> = text
        .lines()
        .map(|line| {
            line.split_whitespace()
                .collect::<Vec<_>>()
                .join(" ")
                .to_lowercase()
        })
        .filter(|line| !line.is_empty())
        .collect();
    if lines.is_empty() {
        return 0.0;
    }
    let unique = lines.iter().collect::<std::collections::HashSet<_>>().len();
    1.0 - unique as f64 / lines.len() as f64
}

fn render_markdown(report: &BenchmarkReport) -> String {
    let mut out = String::from("# PDF Stage Benchmark\n\n");
    out.push_str("| Fixture | Status | Chunks | Max Tokens | Over Cap | No Layout Chars | Layout Chars | Fragments | Span Coverage | References | Failures |\n");
    out.push_str("| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | --- | --- |\n");
    for fixture in &report.fixtures {
        out.push_str(&format!(
            "| `{}` | `{}` | {} | {} | {} | {} | {} | {} | {:.2} | poppler: `{}`, pdfium: `{}` | {} |\n",
            fixture.fixture_id,
            fixture.status,
            fixture.chunks.chunk_count,
            fixture.chunks.max_chunk_tokens,
            fixture.chunks.over_cap_chunks,
            fixture
                .stages
                .ours_no_layout_post_filters
                .as_ref()
                .map(|s| s.normalized_chars)
                .unwrap_or(0),
            fixture
                .stages
                .ours_layout_post_filters
                .as_ref()
                .map(|s| s.normalized_chars)
                .unwrap_or(0),
            fixture.location.fragment_count,
            fixture.location.output_span_coverage_ratio,
            fixture.references.poppler_pdftotext.status,
            fixture.references.pdfium_raw.status,
            if fixture.failures.is_empty() {
                "-".to_string()
            } else {
                fixture.failures.join("; ")
            }
        ));
    }
    out
}

fn resolve_path(manifest_dir: &Path, path: &str) -> PathBuf {
    let candidate = PathBuf::from(path);
    if candidate.is_absolute() {
        candidate
    } else {
        manifest_dir.join(candidate)
    }
}

fn read_flag(args: &[String], name: &str) -> Option<String> {
    args.windows(2)
        .find(|window| window[0] == name)
        .map(|window| window[1].clone())
}
